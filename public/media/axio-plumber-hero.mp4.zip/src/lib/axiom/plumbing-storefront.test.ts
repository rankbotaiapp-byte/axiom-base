import assert from "node:assert/strict";
import test from "node:test";
import {
  DEFAULT_PLUMBING_STOREFRONT,
  dialDigits,
  dialNumber,
  fillTemplate,
  missedCallScript,
  parsePlumbingStorefront,
  safeHref,
  safeMediaUrl,
} from "./plumbing-storefront.ts";

test("junk input falls back to the full default storefront", () => {
  const parsed = parsePlumbingStorefront(null);
  assert.equal(parsed.company, DEFAULT_PLUMBING_STOREFRONT.company);
  assert.equal(parsed.badges.length, DEFAULT_PLUMBING_STOREFRONT.badges.length);
  assert.equal(parsed.phoneDial, "");
  assert.equal(dialNumber(parsed), "+15415550142");
  assert.equal(dialNumber({ phoneDisplay: "(541) 555-0142", phoneDial: "541-555-9999" }), "541-555-9999");
  assert.deepEqual(parsePlumbingStorefront("{not json"), parsed);
});

test("edits survive and are trimmed and capped", () => {
  const parsed = parsePlumbingStorefront({
    company: "  Valley   Rooter  ",
    hero: { headline: "x".repeat(400), grade: 180 },
    badges: [{ label: "Bonded", icon: "nope" }, { label: "" }],
  });
  assert.equal(parsed.company, "Valley Rooter");
  assert.equal(parsed.hero.headline.length, 120);
  assert.equal(parsed.hero.grade, 100);
  assert.deepEqual(parsed.badges, [{ id: "b1", icon: "shield", label: "Bonded" }]);
});

test("unsafe links and media are refused", () => {
  assert.equal(safeHref("javascript:alert(1)", "/x"), "/x");
  assert.equal(safeHref("//evil.example", "/x"), "/x");
  assert.equal(safeHref("tel:+15415550142", "/x"), "tel:+15415550142");
  assert.equal(safeHref("https://stripe.com/pay", "/x"), "https://stripe.com/pay");
  assert.equal(safeMediaUrl("/media/../../etc/passwd", "/a.mp4"), "/a.mp4");
  assert.equal(safeMediaUrl("data:video/mp4;base64,AAAA", "/a.mp4"), "/a.mp4");
});

test("phone numbers become dialable", () => {
  assert.equal(dialDigits("(541) 555-0142"), "+15415550142");
  assert.equal(dialDigits("+44 20 7946 0958"), "+442079460958");
  assert.equal(dialDigits("call us"), "");
});

test("an explicit empty proof list and disabled feed are respected", () => {
  const parsed = parsePlumbingStorefront({ proof: { enabled: false, items: [] } });
  assert.equal(parsed.proof.enabled, false);
  assert.deepEqual(parsed.proof.items, []);
});

test("missed-call script is ordered and uses the company name", () => {
  const steps = missedCallScript(DEFAULT_PLUMBING_STOREFRONT);
  for (let i = 1; i < steps.length; i++) assert.ok(steps[i].at > steps[i - 1].at);
  assert.equal(steps[0].kind, "ring");
  assert.equal(steps.at(-1)?.kind, "booked");
  const first = steps.find((s) => s.kind === "sms-out");
  assert.ok(first && "body" in first && first.body.includes("Rogue Rapid Plumbing"));
  assert.equal(fillTemplate("{a} {b} {c}", { a: "1", b: "2" }), "1 2 {c}");
});

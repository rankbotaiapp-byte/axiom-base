"use client";

import { useRef } from "react";
import WaterCanvas from "./water/WaterCanvas";

type Props = {
  ctaHref?: string;
  videoSrc?: string;
  posterSrc?: string;
};

export default function AxiomHero({
  ctaHref = "/trial",
  videoSrc = "/media/otter-hero-animation.mp4",
  posterSrc = "/media/otter-hero-poster.jpg",
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);

  return (
    <section className="relative h-[100svh] w-full touch-none select-none overflow-hidden bg-[#020c0e]">
      {/* Layer 0 — cinematic base video (also the no-WebGL fallback) */}
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full object-cover"
        src={videoSrc}
        poster={posterSrc}
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        aria-hidden
      />

      {/* Layer 1 — WebGL lens: droplets + ripple refraction of the video */}
      <WaterCanvas videoRef={videoRef} />

      {/* Layer 2 — UI. Wrapper ignores pointers so empty space still ripples. */}
      <div className="pointer-events-none absolute inset-0 flex flex-col">
        <header className="flex items-center justify-between px-6 pt-6 sm:px-10 sm:pt-8">
          <span className="text-sm font-semibold tracking-[0.35em] text-white/90">AXIOM</span>
          <span className="hidden text-xs uppercase tracking-[0.25em] text-cyan-200/70 sm:block">
            Apps that launch in minutes
          </span>
        </header>

        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <h1
            className="text-[clamp(4.5rem,18vw,13rem)] font-black leading-[0.85] tracking-tight text-white"
            style={{ textShadow: "0 0 40px rgba(45,226,230,0.35), 0 4px 24px rgba(0,0,0,0.6)" }}
          >
            AXIOM
          </h1>
          <p className="mt-5 max-w-md text-balance text-base text-white/85 sm:text-lg">
            Your business app, live on your customers&apos; phones in minutes — and built to scale as far as you go.
          </p>

          <a
            href={ctaHref}
            className="pointer-events-auto mt-9 inline-flex items-center gap-3 rounded-full bg-cyan-300 px-8 py-4 text-base font-bold text-[#021417] shadow-[0_0_40px_rgba(45,226,230,0.45)] transition hover:scale-[1.03] hover:bg-cyan-200 focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-200/60 active:scale-[0.98] sm:text-lg"
          >
            <span className="rounded-full bg-[#021417] px-2.5 py-0.5 text-sm text-cyan-300">$1</span>
            Choose Your Price Trial
          </a>
          <p className="mt-3 text-xs text-white/60">Start for $1. Pay what it&apos;s worth after.</p>
        </div>

        <footer className="pb-6 text-center text-[11px] uppercase tracking-[0.3em] text-white/45 sm:pb-8">
          Tap or swipe the water
        </footer>
      </div>
    </section>
  );
}

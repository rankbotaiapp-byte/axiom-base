# Axiom — Cinematic Water Hero

Full-screen otter video + a custom WebGL fragment shader (droplets landing on the lens and tap/swipe ripples), with Tailwind UI on top.

## Run it

```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
```

You don't need any 3D packages. The shader is raw WebGL1 (GLSL ES 1.00), so there's no three.js or R3F (about 150KB less JS) and it runs on older iPhones too.
New project from scratch instead:

```bash
npx create-next-app@latest axiom-hero --ts --tailwind --app --eslint --use-npm
cd axiom-hero && npm i geist
# copy components/, app/, public/media/ from this zip
```

## Structure

```
app/
  layout.tsx            fonts (self-hosted geist), metadata, viewport
  page.tsx              <AxiomHero ctaHref="/trial" />
  globals.css
components/
  AxiomHero.tsx         video layer + canvas layer + UI layer
  water/
    WaterCanvas.tsx     WebGL setup, video→texture pump, drop spawner, pointer input
    shaders.ts          vertex + fragment shader (GLSL)
public/media/
  otter-hero-animation.mp4   (re-encoded: 2.2MB, faststart, no audio)
  otter-hero-poster.jpg      first frame for instant paint
```

## How the layers work

1. `<video>`: autoplay, loop, muted, playsInline, object-cover. If WebGL is unavailable, this is all the visitor sees, so the page never breaks.
2. `<canvas>`: samples the video every new frame (`requestVideoFrameCallback`), applies object-fit: cover math in the shader, then:
   - **Ripples**: up to 24 damped circular wave packets. The surface slope bends UV lookups (refraction), with a light chromatic split and teal light on the crests.
   - **Droplets**: up to 28 hemisphere lenses. Each one shows an inverted, magnified view (like a real drop on a lens), with a darker rim, a specular highlight and a contact shadow. Drops grow on impact, send out a splash ripple, creep down, wobble and evaporate.
3. UI: the wrapper is `pointer-events-none`, and only the CTA is `pointer-events-auto`. Input is listened on `window`, so taps anywhere make ripples, including on the button.

## Tuning knobs

- `<WaterCanvas dropInterval={1.1} maxDpr={1.75} />`: lower dropInterval means more rain. Lower maxDpr means faster on cheap phones.
- In `shaders.ts`: `front = t * 0.42` (wave speed), `* 0.028` (refraction strength), `* 3.2` (drop magnification).
- `prefers-reduced-motion` turns off automatic drops (taps still ripple).

import AxiomHero from "@/components/AxiomHero";

export default function Home() {
  return (
    <main>
      <AxiomHero ctaHref="/trial" />
    </main>
  );
}
